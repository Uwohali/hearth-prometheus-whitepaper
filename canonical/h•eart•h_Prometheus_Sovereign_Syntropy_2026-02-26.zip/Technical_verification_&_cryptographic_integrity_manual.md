Work for Nature,
and Nature will work for you

h•eart•h Prometheus — Sovereign Syntropy
The syntropic kernel for autonomous life-systems
A human pact for h•eart•h intelligence

# Technical verification & cryptographic integrity manual

**Author**: Uwohali Tuccio
**Publisher**: Permaculture DAO LLC
**Date**: February 26, 2026
**Version**: 1.0 (Sovereign Syntropy Release)
**Status**: Final release
**Constitutional Reference**: h•eart•h_Prometheus_White_Paper (February 26, 2026)

---

## 1. Introduction & purpose

This manual provides complete technical instructions for verifying the cryptographic integrity and authenticity of the h•eart•h Prometheus Sovereign Syntropy White Paper and its constitutionally incorporated documents. The framework employs a sophisticated cryptographic architecture that binds constitutional text to mathematical proof, ensuring immutability, non‑repudiation, and resistance to revisionism.

In alignment with Article XI (Operational Syntropic Sovereignty) and the eternity clauses (Articles I, II, III, IV, X, XIII), this verification protocol is not merely a technical option but a foundational act of sovereignty. By verifying these documents, you acknowledge the natural laws they encode and enter into the Access Covenant that governs participation in the h•eart•h Prometheus ecosystem.

---

## 2. Constitutional foundation

The h•eart•h Prometheus sovereign syntropy framework constitutes the foundational law of this system. All system components operate under three constitutionally incorporated documents, forming an indivisible legal‑technical trinity that embodies the two flames of holistic sovereignty: behavioral sovereignty (TRBK) and digital sovereignty (Holochain).

| Document | File | SHA‑256 | Role |
|----------|------|---------|------|
| Syntropic Sovereignty Header | `Syntropic_Sovereignty_Header.md` | C6FC3B192236D953B94AB33F641FE80FAD507471647872373BCAC58E20C3775E | Cryptographic enforcement of syntropic logic at the data‑packet level; implements Article XI |
| h•eart•h intelligence Manifesto | `h•eart•h_intelligence_Manifesto.md` | D80963DD7E6E41B3CF488C157FE1B1F93A256E862548400542B318ACFACC7E9B | Ethical and philosophical bedrock defining the "spiral of Abundance" and the sacred pact |
| CAL‑1.0 Syntropic rider license | `CAL-1.0_Syntropic_rider_license.md` | 97682D44A641E7D205037DCE55DA018AEC8B00FF0A75369BEBD22C06AE6B6D3B | Legal bridge ensuring that software usage remains in service of Life, binding all code to constitutional principles |

**Cryptographic incorporation principle**: These documents are incorporated via their SHA‑256 hashes. Their constitutional validity is perpetual and independent of physical availability. Any interaction with the White Paper constitutes acceptance of these documents in their exact hashed versions, as mandated by the Access Covenant (Article XV, Section 5).

---

## 3. Cryptographic architecture

### 3.1 Document hierarchy & verification chain

The verification chain is anchored to the canonical source, which itself carries the syntropic sovereignty header and is signed by the sovereign key.

**Primary Source**: `h•eart•h_Prometheus_White_Paper.md`  
**Canonical SHA‑256**: FDD07069930DAFE5976065C714B8D5CD8C5B2E06AF76C2F3F696DBC3A8365744

All files are signed with the sovereign key of Uwohali Tuccio, acting as the constitutional steward for Permaculture DAO LLC.

### 3.2 Key authority & rotation

In accordance with Appendix D (Syntropic Sovereignty Header) and the DPKI registry specifications, the following key is the sole authority for signing constitutional documents:

- **Current key (Active)**: `0xD20DFF6CBE331B3A4109DF848C8CB0D48C7F60DA`
- **Signatory**: Uwohali Tuccio (The Constituent)
- **Validity Period**: February 26, 2026 to February 26, 2028
- **Fingerprint**: `D20D FF6C BE33 1B3A 4109 DF84 8C8C B0D4 8C7F 60DA`

Key rotation follows the protocol defined in Appendix D.2.4, requiring a supermajority vote of the Prometheus circle and the consent of the custodians (TRBK and Holochain communities) to maintain the integrity of the two flames.

---

## 4. Verification package structure

### 4.1 Package identification

The official verification package is distributed as a ZIP archive containing all four constitutional documents and their corresponding detached GPG signatures.

**Filename**: `h•eart•h_Prometheus_YYYY-MM-DD.zip` (the date in the filename corresponds to the release date)

**Contents**:
- `h•eart•h_Prometheus_White_Paper.md`
- `h•eart•h_Prometheus_White_Paper.md.asc` (detached signature)
- `Syntropic_Sovereignty_Header.md`
- `h•eart•h_intelligence_Manifesto.md`
- `CAL-1.0_Syntropic_rider_license.md`
- `Uwohali_Tuccio_PUBLIC_KEY.asc` (public key for verification)
- This manual (`Verification_Manual.md`)
- `README.md`
- `VERIFICATION.md`

### 4.2 Expected file hashes

| File | SHA‑256 |
|------|---------|
| `h•eart•h_Prometheus_White_Paper.md` | 98A36DD9D52426EFF3B124F23FD6267D52DE73A849C8D60FBCFF408187353154 |
| `Syntropic_Sovereignty_Header.md` | 14C091D52E19F7A93DB633406FD4EF64BF537906FFEB212A43F4A7E80B836A0D |
| `h•eart•h_intelligence_Manifesto.md` | D80963DD7E6E41B3CF488C157FE1B1F93A256E862548400542B318ACFACC7E9B |
| `CAL-1.0_Syntropic_rider_license.md` | DDA81DC4C96B73B3455A17B05DBD6841385665E9C81603BC635690931203FA13 |
| `README.md` | FA042636C5937E0D87C94898EDCBCCAC757FD21598980AA564128173F4E572AF |
| `VERIFICATION.md` | A77746CDFED3A139827CB6438252F6CCBC060C48670A283280AB455296276DB9 |

---

## 5. Step‑by‑step verification procedures

The following instructions assume a Unix‑like environment (Linux, macOS, or Windows Subsystem for Linux). For native Windows, equivalent commands using Gpg4win or PowerShell can be used; refer to the documentation of your tools.

### Step 1: Obtain the public key

The public key is included in the verification package as `Uwohali_Tuccio_PUBLIC_KEY.asc`. You can also download it from a trusted source (e.g., official website, key servers). Ensure the key fingerprint matches the one in Section 3.2.

### Step 2: Import the public key

```bash
gpg --import Uwohali_Tuccio_PUBLIC_KEY.asc
Expected output:

text
gpg: key 0xD20DFF6CBE331B3A4109DF848C8CB0D48C7F60DA: public key "Uwohali Tuccio (The Constituent) <uwohali77@gmail.com>" imported
Step 3: Verify the digital signature of the White Paper
bash
gpg --verify h•eart•h_Prometheus_White_Paper.md.asc h•eart•h_Prometheus_White_Paper.md
Success criteria:
The output must contain a line like:

text
gpg: Good signature from "Uwohali Tuccio (The Constituent) <uwohali77@gmail.com>"
It may also show a warning that the key is not certified with a trusted signature – this is normal if you have not assigned ultimate trust to the key. The critical part is the "Good signature" confirmation.

Step 4: Verify the anchor hash of the White Paper
bash
sha256sum h•eart•h_Prometheus_White_Paper.md
Compare the output with the hash published in Section 4.2. They must match exactly.

Step 5: (Optional) Verify the hashes of the incorporated documents
For full constitutional assurance, verify the integrity of the three supporting documents:

bash
sha256sum Syntropic_Sovereignty_Header.md
sha256sum h•eart•h_intelligence_Manifesto.md
sha256sum CAL-1.0_Syntropic_rider_license.md
Compare each result with the corresponding hash in Section 4.2.

6. Legal & constitutional implications
6.1 Cryptographic incorporation
By verifying and accepting the signed White Paper, you acknowledge that the three incorporated documents are constitutionally binding and their validity derives from cryptographic proof. This act constitutes implicit acceptance of the Access Covenant (Article XV, Section 5) and the eternity clauses that protect the foundational laws of Nature.

6.2 Jurisdiction & Lex Informatica
This protocol is governed by Lex Informatica (self‑executing code). In alignment with Article 8.4 of the Syntropic Sovereignty Header and the principle of maximum protection of the data subject (Art. 3 GDPR), Permaculture DAO LLC formally waives the forum of its registered office. The sole competent forum for any dispute is the residence of the data subject.

For civil law jurisdictions requiring explicit jurisdictional assignment, this clause is self‑executing. Disputes regarding cryptographic integrity are resolved through on‑chain technical arbitration, where cryptographic proof prevails over any textual claim, as validated by the network's validation rules.

6.3 Role of the custodians
The verification of these documents also affirms the role of the custodians of the two flames (Article XV, Section 3):

The TRBK community as custodians of behavioral sovereignty

The Holochain ecosystem as custodians of digital and biological sovereignty

Any attempt to alter these documents without the consent of these custodians and a supermajority vote of the Prometheus circle is void ab initio (Article II).

7. Certification
Enacted: February 26, 2026
Version: 1.0 (Sovereign Syntropy Release)
Author: Uwohali Tuccio
Publisher: Permaculture DAO LLC
Verification Suite: OpenPGP + SHA‑256
Signing key fingerprint: D20D FF6C BE33 1B3A 4109 DF84 8C8C B0D4 8C7F 60DA
Key validity: February 26, 2026 – February 26, 2028

Work for Nature,
and Nature will work for you

© 2026 Permaculture DAO LLC
All rights reserved